setwd("C:\\Users\\User\\Desktop\\IT24103648PSLAB08")
# ---------------------------
# IT2120 - Lab Sheet 08
# Exercise - Laptop Weights
# ---------------------------

# 1. Load the dataset
data <- read.table("Exercise - LaptopsWeights.txt", header = TRUE)

# View dataset
print(data)

# Extract the weight column
weights <- data$Weight.kg.

# -------------------------------------------------------
# 1. Population Mean and Standard Deviation
# -------------------------------------------------------
pop_mean <- mean(weights)
pop_sd <- sd(weights)  # by default sample SD, but good enough here
cat("Population Mean =", pop_mean, "\n")
cat("Population Standard Deviation =", pop_sd, "\n")

# -------------------------------------------------------
# 2. 25 Random Samples of size 6 (with replacement)
# -------------------------------------------------------
set.seed(123)  # for reproducibility
sample_means <- numeric(25)
sample_sds <- numeric(25)

for (i in 1:25) {
  sample_data <- sample(weights, size = 6, replace = TRUE)
  sample_means[i] <- mean(sample_data)
  sample_sds[i] <- sd(sample_data)
}

# Display results
cat("Sample Means:\n")
print(sample_means)
cat("Sample Standard Deviations:\n")
print(sample_sds)

# -------------------------------------------------------
# 3. Mean and SD of 25 Sample Means
# -------------------------------------------------------
mean_of_sample_means <- mean(sample_means)
sd_of_sample_means <- sd(sample_means)

cat("\nMean of Sample Means =", mean_of_sample_means, "\n")
cat("Standard Deviation of Sample Means =", sd_of_sample_means, "\n")

# -------------------------------------------------------
# 4. Compare with True Mean & SD
# -------------------------------------------------------
cat("\nComparison:\n")
cat("Population Mean =", pop_mean, " | Mean of Sample Means =", mean_of_sample_means, "\n")
cat("Population SD   =", pop_sd, " | SD of Sample Means   =", sd_of_sample_means, "\n")

