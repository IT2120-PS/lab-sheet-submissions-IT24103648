setwd("C:\\Users\\User\\Desktop\\IT24103648LAB06PS")
# Exercise 1: IT Company Learning Platform
cat("Exercise 1: IT Company Learning Platform\n")
cat("========================================\n")

# Part i: Distribution of X
cat("i. Distribution of X: Binomial distribution with n=50, p=0.85\n")

# Part ii: P(X ≥ 47) - Probability that at least 47 students passed
prob_ex1_ii <- pbinom(46, 50, 0.85, lower.tail = FALSE)
cat("ii. P(X ≥ 47) =", round(prob_ex1_ii, 4), "\n\n")


# Exercise 2: Call Center Calls
cat("Exercise 2: Call Center Calls\n")
cat("==============================\n")

# Part i: Random variable X
cat("i. Random variable X: Number of customer calls received in an hour\n")

# Part ii: Distribution of X
cat("ii. Distribution of X: Poisson distribution with lambda=12\n")

# Part iii: P(X = 15) - Probability of exactly 15 calls
prob_ex2_iii <- dpois(15, 12)
cat("iii. P(X = 15) =", round(prob_ex2_iii, 4), "\n")
